export interface LandingContent {
  urgencyBanner: string;
  nav: {
    brand: string;
    links: { label: string; href: string }[];
    cta: string;
  };
  hero: {
    kicker: string;
    title: string;
    titleHighlight: string;
    subtitle: string;
    tagline: string;
    ctaPrimary: string;
    ctaMicrocopy: string;
    bulletPoints: string[];
    checkoutUrl: string;
  };
  fearAndPain: {
    kicker: string;
    title: string;
    subtitle: string;
    stagesTitle: string;
    stages: {
      step: string;
      title: string;
      description: string;
      warning: string;
    }[];
    wakeUpCall: {
      question: string;
      highlight: string;
      paragraph1: string;
      paragraph2: string;
      callout: string;
      ctaText: string;
    };
  };
  quiz: {
    kicker: string;
    title: string;
    subtitle: string;
    instruction: string;
    symptoms: {
      id: string;
      label: string;
      impact: string;
    }[];
    resultsTitle: string;
    lowScoreText: string;
    midScoreText: string;
    highScoreText: string;
    recommendationTitle: string;
    ctaText: string;
  };
  solution: {
    kicker: string;
    title: string;
    subtitle: string;
    pillars: {
      number: string;
      title: string;
      recipeCount: string;
      focus: string;
      description: string;
      examples: string[];
    }[];
    highlights: {
      title: string;
      description: string;
    }[];
  };
  comparison: {
    kicker: string;
    title: string;
    subtitle: string;
    optionOld: {
      badge: string;
      title: string;
      cost: string;
      items: string[];
      consequence: string;
    };
    optionNew: {
      badge: string;
      title: string;
      cost: string;
      items: string[];
      consequence: string;
    };
  };
  bonuses: {
    kicker: string;
    title: string;
    subtitle: string;
    items: {
      badge: string;
      title: string;
      originalPrice: string;
      description: string;
    }[];
  };
  testimonials: {
    kicker: string;
    title: string;
    subtitle: string;
    items: {
      name: string;
      age: string;
      location: string;
      result: string;
      quote: string;
      timeframe: string;
    }[];
  };
  offer: {
    kicker: string;
    title: string;
    subtitle: string;
    timerText: string;
    originalPrice: string;
    currentPrice: string;
    paymentNote: string;
    guaranteeTitle: string;
    guaranteeText: string;
    ctaText: string;
    securityBadges: string[];
  };
  faq: {
    kicker: string;
    title: string;
    items: {
      q: string;
      a: string;
    }[];
  };
  footer: {
    disclaimer: string;
    rights: string;
  };
}

export const spanishContent: LandingContent = {
  urgencyBanner: '⚠️ ALERTA DE SALUD: El precio especial de liberación inmediata y los 3 bonos de regalo terminan hoy.',
  nav: {
    brand: 'BIENESTAR NATURAL',
    links: [
      { label: 'La Alerta Silenciosa', href: '#alerta' },
      { label: 'Test de Sobrecarga', href: '#diagnostico' },
      { label: 'Las 85 Recetas', href: '#receitas' },
      { label: 'Testimonios', href: '#testimonios' },
      { label: 'Garantía', href: '#garantia' },
    ],
    cta: 'Obtener Mi Guía Ahora',
  },
  hero: {
    kicker: 'LA SEÑAL INVISIBLE QUE NO PUEDES SEGUIR IGNORANDO',
    title: 'Tu cuerpo está pidiendo auxilio en silencio.',
    titleHighlight: '¿Hasta cuándo vas a normalizar vivir con fatiga, vientre hinchado y dependiendo de pastillas?',
    subtitle: 'Aprende a despertar la capacidad autocurativa de tu organismo mediante más de 85 recetas naturales milenarias de infusiones medicinales, tónicos depurativos y jugos funcionales con ingredientes cotidianos que ya tienes en tu cocina.',
    tagline: 'Tu salud empieza en la cocina',
    ctaPrimary: '¡QUIERO DESINTOXICAR MI CUERPO AHORA!',
    ctaMicrocopy: 'Acceso digital inmediato en móvil, tablet y PC · Pago 100% seguro Hotmart · Garantía de 7 días',
    bulletPoints: [
      'Mejora la digestión y elimina gases, pesadez y acidez tras comer',
      'Depura el hígado y desinflama el vientre de forma natural',
      'Cuida el corazón, regula la circulación y alivia piernas pesadas',
      'Ingredientes 100% cotidianos de frutería y mercado local',
      'Preparaciones en menos de 5 minutos con instrucciones y dosis exactas',
    ],
    checkoutUrl: 'https://pay.hotmart.com/F108039909R',
  },
  fearAndPain: {
    kicker: 'LA CRUDA REALIDAD DEL "DESPUÉS LO HAGO"',
    title: 'La mayoría de las personas solo reacciona cuando el análisis médico arroja una noticia aterradora.',
    subtitle: 'Crees que la fatiga matinal, el reflujo nocturno y el vientre constantemente hinchado son solo "estrés" o "la edad". Pero tu cuerpo está gritando que su filtro principal está colapsado de toxinas.',
    stagesTitle: 'Las 4 Etapas del Deterioro Biológico Silencioso',
    stages: [
      {
        step: 'Etapa 01',
        title: 'La Saturación Inicial de Toxinas',
        description: 'Despiertas con sabor amargo en la boca, sientes la digestión lenta y pesada, y el vientre se inflama incluso tras comer una ensalada. El cansancio se convierte en tu estado habitual de vida.',
        warning: 'Signo inequívoco de sobrecarga en el hígado e inflamación digestiva.',
      },
      {
        step: 'Etapa 02',
        title: 'El Hígado Graso y Metabolismo Bloqueado',
        description: 'Tu hígado ya no logra filtrar el exceso de impurezas. Empieza a acumular grasa visceral en la zona abdominal, el colesterol se altera y tu cuerpo entra en modo de resistencia y almacenamiento.',
        warning: 'Haces dietas estrictas sin bajar un solo gramo mientras sufres mareos y dolores de cabeza.',
      },
      {
        step: 'Etapa 03',
        title: 'La Trampa Peligrosa de los Fármacos Diarios',
        description: '¿Dolor de cabeza? Analgésico. ¿Acidez y reflujo? Omeprazol o antiácido. ¿Insomnio? Somnífero. Gastas decenas de euros/dólares cada mes silenciando la alarma de incendio mientras el fuego devora tu salud por dentro.',
        warning: 'Las pastillas sintéticas dañan la mucosa gástrica y sobrecargan aún más riñones e hígado.',
      },
      {
        step: 'Etapa 04',
        title: 'El Choque del Diagnóstico Crónico',
        description: 'Presión arterial descontrolada, esteatosis hepática avanzada (hígado graso grado 2 o 3), gastritis crónica severa y las temidas palabras del médico: "Tendrá que tomar esta medicación por el resto de su vida".',
        warning: 'El punto en el que el 90% se arrepiente con lágrimas de no haber cuidado su cuerpo a tiempo.',
      },
    ],
    wakeUpCall: {
      question: '¿Dónde estará tu salud dentro de 12 meses si continúas ignorando estas señales?',
      highlight: 'El tiempo no perdona. Cada día que pasas con el organismo congestionado es un día más dañando tus células y arterias.',
      paragraph1: 'Los medicamentos químicos fueron creados para urgencias médicas puntuales, no para ser tu desayuno diario. Cuando tomas pastillas para tapar el dolor de cabeza o el ardor estomacal, no estás curando nada: solo estás desconectando el cable de la alarma.',
      paragraph2: 'La sabiduría botánica milenaria de plantas, raíces y compuestos bioactivos tiene la capacidad comprobada de estimular la regeneración hepática, desatascar las vías biliares y restaurar tu energía sin efectos secundarios.',
      callout: 'La pregunta decisiva que debes hacerte ahora es: ¿Vas a esperar un susto médico irreversible para empezar a cuidar tu único cuerpo?',
      ctaText: 'Basta de Arriesgar Mi Salud — Quiero Depurar Mi Cuerpo',
    },
  },
  quiz: {
    kicker: 'TEST RÁPIDO DE SOBRECARGA ORGÁNICA',
    title: 'Evalúa el Nivel de Toxicidad e Inflamación de Tu Cuerpo',
    subtitle: 'Marca los síntomas que has experimentado en los últimos 30 días para calcular tu nivel de toxinas acumuladas:',
    instruction: 'Selecciona todos los que correspondan a tu día a día:',
    symptoms: [
      { id: 'fatigue', label: 'Despierto agotado, como si no hubiera dormido nada en toda la noche', impact: 'Fatiga adrenal y sobrecarga en el hígado' },
      { id: 'bloat', label: 'Vientre duro, hinchado o gases incómodos después de comer', impact: 'Disbiosis y fermentación gástrica continua' },
      { id: 'acid', label: 'Acidez, ardor en el pecho, reflujo o sabor amargo al despertar', impact: 'Desbalance en ácidos digestivos y bilis' },
      { id: 'slow_meta', label: 'Metabolismo estancado y dificultad extrema para perder peso', impact: 'Hígado congestionado bloqueando quema lipídica' },
      { id: 'headache', label: 'Dolores de cabeza recurrentes, migraña o pesadez en la nuca', impact: 'Exceso de toxinas circulantes en sangre' },
      { id: 'sleep', label: 'Dificultad para conciliar el sueño o despertares bruscos a las 3:00 AM', impact: 'Pico de cortisol y ciclo hepático alterado' },
      { id: 'joints', label: 'Piernas pesadas, tobillos hinchados o dolores articulares', impact: 'Retención de líquidos e inflamación sistémica' },
    ],
    resultsTitle: 'Diagnóstico Estimado de Tu Organismo:',
    lowScoreText: 'Muestras signos iniciales de sobrecarga digestiva. Actuar ahora evitará complicaciones hepáticas, esteatosis y fatiga crónica.',
    midScoreText: 'ALERTA MODERADA: Tu organismo está saturado de toxinas. El hígado y el intestino están trabajando forzados y necesitan depuración urgente.',
    highScoreText: 'ALERTA CRÍTICA: Tu cuerpo se encuentra en un estado de inflamación severa y congestión celular. Ignorar esto compromete seriamente tu salud futura.',
    recommendationTitle: 'Protocolo Inmediato Recomendado:',
    ctaText: 'Quiero el Protocolo de 85 Recetas para Limpiar Mi Cuerpo Hoy',
  },
  solution: {
    kicker: 'LA SOLUCIÓN NATURAL, PRÁCTICA Y EFECTIVA',
    title: 'Más de 85+ Recetas Naturales para el Bienestar Diario',
    subtitle: 'Sin dietas imposibles, sin polvos costosos y sin pasar horas en la cocina. El poder curativo de las plantas explicado paso a paso.',
    pillars: [
      {
        number: '01',
        title: 'Digestión y Vientre Ligero',
        recipeCount: '20+ Recetas',
        focus: 'Fin de gases, reflujo, acidez y pesadez estomacal',
        description: 'Infusiones calmantes con acción carminativa y protectora gástrica que aceleran el vaciado del estómago y evitan la molesta inflamación abdominal.',
        examples: ['Infusión Vientre Ligero (Jengibre, menta, limón y miel)', 'Elixir Carminativo de Hinojo y Manzanilla', 'Infusión Anti-Acidez de Romero'],
      },
      {
        number: '02',
        title: 'Hígado y Depuración Profunda',
        recipeCount: '18+ Recetas',
        focus: 'Limpieza total del filtro biológico del cuerpo',
        description: 'Fórmulas depurativas con fitoquímicos concentrados que ayudan al hígado a procesar lípidos, drenar impurezas y restaurar la producción óptima de bilis.',
        examples: ['Tónico Drenante de Diente de León y Cúrcuma', 'Jugo Verde Hepático con Manzana y Perejil', 'Infusión Protectora Biliar de Boldo'],
      },
      {
        number: '03',
        title: 'Peso Saludable y Metabolismo Activo',
        recipeCount: '16+ Recetas',
        focus: 'Vitalidad matinal y reactivación calórica sin nerviosismo',
        description: 'Combinaciones termogénicas equilibradas que despiertan el gasto energético basal sin provocar taquicardias ni la ansiedad de las bebidas energéticas artificiales.',
        examples: ['Termogénico de Canela de Ceilán, Clavo y Naranja', 'Elixir Matutino de Pimienta de Cayena y Limón', 'Té Verde Bioactivo con Piña'],
      },
      {
        number: '04',
        title: 'Corazón y Circulación Óptima',
        recipeCount: '15+ Recetas',
        focus: 'Vasodilatación natural y alivio de piernas hinchadas',
        description: 'Bebidas ricas en flavonoides que protegen las paredes arteriales, favorecen la presión equilibrada y alivian la retención de líquidos corporales.',
        examples: ['Té de Canela de Ceilán y Cardamomo (Receta 85)', 'Infusión Cardioprotectora de Flor de Jamaica', 'Tónico Circulatorio de Ajo Suave y Cítricos'],
      },
      {
        number: '05',
        title: 'Sueño Reparador y Alivio del Estrés',
        recipeCount: '16+ Recetas',
        focus: 'Descanso profundo sin fármacos sintéticos adictivos',
        description: 'Elixires nocturnos que calman el sistema nervioso central, reducen el cortisol y preparan la glándula pineal para una regeneración nocturna profunda.',
        examples: ['Leche Dorada Relajante con Cúrcuma Pura', 'Infusión Serenidad con Pasiflora, Melisa y Lavanda', 'Té Nocturno de Manzana Cocida y Canela'],
      },
    ],
    highlights: [
      {
        title: 'Ingredientes Cotidianos y Económicos',
        description: 'Nada de polvos raros ni suplementos inalcanzables. Todo se compra en cualquier frutería o mercado local por muy poco dinero.',
      },
      {
        title: 'Preparación en Menos de 5 Minutos',
        description: 'Explicado paso a paso con medidas exactas, tiempos de reposo y los momentos óptimos del día para consumirlas.',
      },
      {
        title: 'Advertencias y Precauciones Claras',
        description: 'Conoce con certeza las propiedades y contraindicaciones de cada planta para consumirlas con total seguridad y tranquilidad.',
      },
    ],
  },
  comparison: {
    kicker: 'LA COMPARATIVA QUE NADIE TE MUESTRA',
    title: 'Compara los Dos Caminos Ante Ti',
    subtitle: '¿Seguirás en el círculo vicioso de la farmacia o invertirás menos de una merienda en tu bienestar definitivo?',
    optionOld: {
      badge: 'CAMINO 01: EL CICLO DE LA DEPENDENCIA',
      title: 'Fármacos que Solo Tapan los Síntomas',
      cost: 'De 40€ a 120€ gastados mes tras mes',
      items: [
        'Antiácidos continuos que debilitan la microbiota estomacal',
        'Pastillas para el dolor que sobrecargan hígado y riñones',
        'Sensación constante de pesadez, vientre hinchado y apatía',
        'El temor latente a un diagnóstico alarmante en tu próxima cita',
        'Dependencia diaria de fármacos para dormir o calmar los nervios',
      ],
      consequence: 'Resultado: Cada año gastas más dinero mientras tu organismo se inflama y envejece prematuramente.',
    },
    optionNew: {
      badge: 'CAMINO 02: LA SABIDURÍA DE LA NATURALEZA',
      title: 'Guía 85+ Recetas Naturales para el Bienestar',
      cost: 'Solo una pequeña aportación simbólica de $6.99',
      items: [
        'Más de 85 recetas probadas y organizadas por objetivos reales',
        'Hígado depurado, digestión ágil y vientre desinflamado',
        'Energía natural al despertar sin dependencia de café excesivo',
        'Ingredientes 100% naturales que cuestan céntimos en el mercado',
        'Autonomía total para cuidar tu salud y la de tu familia en casa',
      ],
      consequence: 'Resultado: Vitalidad recuperada, ligereza y la tranquilidad absoluta de vivir sin dolores.',
    },
  },
  bonuses: {
    kicker: 'EXCLUSIVO PARA QUIEN TOME ACCIÓN HOY',
    title: '3 Bonos Rápidos Incluidos de Regalo',
    subtitle: 'Al asegurar tu copia digital hoy, recibes de inmediato acceso a estos 3 manuales complementarios totalmente gratis:',
    items: [
      {
        badge: 'BONO DE REGALO #1',
        title: 'Plan Detox de 7 Días para Reseteo Hepático',
        originalPrice: 'Valorado por separado en $19.00 USD',
        description: 'Un cronograma guiado día a día para desintoxicar tu hígado y deshincharte en tus primeros 7 días de forma segura y deliciosa.',
      },
      {
        badge: 'BONO DE REGALO #2',
        title: 'Guía de Sustituciones Inteligentes de Hierbas',
        originalPrice: 'Valorado por separado en $15.00 USD',
        description: '¿No encuentras una hierba específica en tu localidad? Descubre al instante el sustituto botánico con igual potencia curativa.',
      },
      {
        badge: 'BONO DE REGALO #3',
        title: 'Lista de Compras del Consumidor Consciente',
        originalPrice: 'Valorado por separado en $12.00 USD',
        description: 'Cómo elegir las hierbas más frescas, ahorrar hasta un 60% comprando a granel y conservarlas para que nunca pierdan propiedades.',
      },
    ],
  },
  testimonials: {
    kicker: 'TESTIMONIOS REALES Y VERIFICABLES',
    title: 'Personas Reales que Salieron del Círculo del Dolor',
    subtitle: 'Mira lo que ocurrió cuando decidieron sanar su organismo con recetas naturales caseras:',
    items: [
      {
        name: 'María Helena Campos',
        age: '52 años',
        location: 'Madrid, España',
        result: 'Reflujo y acidez eliminados en 6 días',
        quote: 'Tomaba pastillas para la acidez todos los días desde hacía 4 años. Cualquier comida me hacía sentir una piedra en el estómago. Con la infusión de la página 1 y el tónico matutino, en menos de una semana se terminó el ardor. ¡He vuelto a disfrutar de comer sin miedo!',
        timeframe: 'Alivio visible al 4º día',
      },
      {
        name: 'Carlos Eduardo M.',
        age: '46 años',
        location: 'Bogotá, Colombia',
        result: 'Hígado graso en notable mejoría',
        quote: 'El médico me asustó al decirme que tenía hígado graso grado 2 y que debía cambiar radicalmente. Este libro fue mi salvación. Las recetas son facilísimas de preparar por la mañana y me las llevo al trabajo. Hoy me siento con la energía que tenía a los 30 años.',
        timeframe: 'Resultados notables en 3 semanas',
      },
      {
        name: 'Silvia Regina Fontes',
        age: '38 años',
        location: 'Santiago, Chile',
        result: 'Adiós al agotamiento diario',
        quote: 'Pensaba que despertar agotada era por el estrés laboral. El problema era la sobrecarga de toxinas en mi digestión. Las infusiones nocturnas y los elixires depurativos cambiaron todo. No volví a tener esa pesada niebla mental por las tardes.',
        timeframe: 'Mayor vitalidad al 2º día',
      },
    ],
  },
  offer: {
    kicker: 'CONDICIÓN ESPECIAL DE LANZAMIENTO',
    title: 'Comienza a Desintoxicar Tu Organismo Hoy Mismo',
    subtitle: 'El precio de esta guía es diminuto frente a una sola consulta privada o lo que gastas en la farmacia cada mes.',
    timerText: 'Esta oferta promocional con 3 bonos finaliza en:',
    originalPrice: '$29.00 USD',
    currentPrice: 'Solo $6.99 USD',
    paymentNote: 'Pago único con acceso digital de por vida · Sin mensualidades ni cobros ocultos',
    guaranteeTitle: 'Garantía Incondicional de 7 Días',
    guaranteeText: 'Tienes 7 días completos para probar las recetas en tu rutina y sentir la ligereza, la depuración y la vitalidad. Si por cualquier motivo decides que no es para ti, con un solo clic en Hotmart te reembolsamos el 100% de tu dinero de inmediato. Sin preguntas y sin letra pequeña.',
    ctaText: '¡SÍ! QUIERO MI GUÍA DE 85+ RECETAS AHORA',
    securityBadges: ['Pago Seguro y Encriptado Hotmart', 'Entrega Inmediata a tu Correo', 'Garantía Blindada de 7 Días', 'Soporte al Lector'],
  },
  faq: {
    kicker: 'PREGUNTAS FRECUENTES',
    title: 'Todo lo que Necesitas Saber Antes de Empezar',
    items: [
      {
        q: '¿Son difíciles o caros de conseguir los ingredientes?',
        a: '¡En absoluto! El 95% de las recetas utilizan plantas, frutas y especias cotidianas que compras en cualquier frutería o mercado de tu barrio (limón, jengibre, romero, manzanilla, menta, cúrcuma, etc.). Ahorrarás dinero en comparación con suplementos procesados.',
      },
      {
        q: 'Tengo muy poco tiempo libre en mi día. ¿Podré prepararlas?',
        a: 'Sí, las recetas están diseñadas específicamente para personas con vidas ocupadas. La mayoría se preparan en menos de 3 a 5 minutos por la mañana o por la noche.',
      },
      {
        q: '¿Puedo tomarlas si ya consumo medicación médica?',
        a: 'La guía incluye advertencias claras y precauciones para un consumo responsable, indicando qué plantas interactúan con ciertos medicamentos (como anticoagulantes). Siempre recomendamos consultar a tu médico ante cualquier duda.',
      },
      {
        q: '¿Cómo recibiré la guía digital después de pagar?',
        a: 'Inmediatamente tras confirmarse tu pago en Hotmart, recibirás un correo electrónico con tu acceso privado para descargar y leer la guía en tu móvil, tablet o PC. También puedes imprimirla si prefieres.',
      },
      {
        q: '¿Qué garantía tengo si no me convence?',
        a: 'Tienes 7 días de garantía incondicional gestionada directamente por Hotmart. Si no estás 100% satisfecho, pides el reembolso y recuperas tu dinero de forma automática.',
      },
    ],
  },
  footer: {
    disclaimer: 'Aviso Legal: Esta guía digital tiene propósitos informativos y educativos sobre bienestar natural. No sustituye el consejo, diagnóstico o tratamiento médico profesional. Consulta a tu médico antes de realizar cambios drásticos en tu alimentación.',
    rights: '© 2026 Más de 85+ Recetas Naturales para el Bienestar Diario. Todos los derechos reservados. Procesado de forma 100% segura por Hotmart.',
  },
};
