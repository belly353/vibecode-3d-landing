import React from 'react';
import { AlertTriangle, Clock, ArrowDownRight, Flame, HeartCrack, Skull } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface SilentAlertProps {
  content: LandingContent;
  onCtaClick: () => void;
}

export const SilentAlert: React.FC<SilentAlertProps> = ({ content, onCtaClick }) => {
  const getStageIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Clock className="w-5 h-5 text-amber-500" />;
      case 1:
        return <Flame className="w-5 h-5 text-orange-500" />;
      case 2:
        return <AlertTriangle className="w-5 h-5 text-rose-500" />;
      case 3:
        return <Skull className="w-5 h-5 text-red-500" />;
      default:
        return <HeartCrack className="w-5 h-5 text-rose-500" />;
    }
  };

  return (
    <section id="alerta" className="py-16 lg:py-24 bg-stone-900 text-stone-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-amber-400 uppercase">
            <span>{content.fearAndPain.kicker}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight text-white leading-tight" style={{ textWrap: 'balance' }}>
            {content.fearAndPain.title}
          </h2>

          <p className="text-stone-300 text-base sm:text-lg leading-relaxed">
            {content.fearAndPain.subtitle}
          </p>
        </div>

        {/* The 4 Stages of Biological Deterioration Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {content.fearAndPain.stages.map((stage, idx) => (
            <div
              key={idx}
              className="bg-stone-800/80 border border-stone-700/80 rounded-2xl p-6 sm:p-8 flex flex-col justify-between hover:border-amber-500/40 transition-colors"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    {getStageIcon(idx)}
                    <span className="text-xs font-bold text-amber-400 tracking-wider uppercase">
                      {stage.step}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-stone-500">0{idx + 1}/04</span>
                </div>

                <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                  {stage.title}
                </h3>

                <p className="text-sm sm:text-base text-stone-300 leading-relaxed">
                  {stage.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-stone-700/60 flex items-start gap-2.5 text-xs text-rose-300 bg-rose-950/40 p-3 rounded-lg border border-rose-900/40">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{stage.warning}</span>
              </div>
            </div>
          ))}
        </div>

        {/* The Reality Wake-Up Call Box */}
        <div className="mt-14 max-w-4xl mx-auto bg-gradient-to-b from-stone-800 to-stone-850 border border-amber-500/30 rounded-2xl p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="space-y-6 relative">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
              <ArrowDownRight className="w-4 h-4" />
              <span>Momento de Reflexión Urgente</span>
            </div>

            <h3 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white leading-snug">
              {content.fearAndPain.wakeUpCall.question}
            </h3>

            <p className="text-base sm:text-lg font-medium text-amber-200/90 leading-relaxed">
              {content.fearAndPain.wakeUpCall.highlight}
            </p>

            <div className="space-y-4 text-sm sm:text-base text-stone-300 leading-relaxed">
              <p>{content.fearAndPain.wakeUpCall.paragraph1}</p>
              <p>{content.fearAndPain.wakeUpCall.paragraph2}</p>
            </div>

            <div className="p-4 sm:p-5 bg-stone-900/90 rounded-xl border border-stone-700 text-stone-200 text-sm sm:text-base italic font-serif">
              "{content.fearAndPain.wakeUpCall.callout}"
            </div>

            <div className="pt-2 text-center sm:text-left">
              <button
                onClick={onCtaClick}
                type="button"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 text-base font-bold text-stone-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl shadow-lg transition-all cursor-pointer"
              >
                <span>{content.fearAndPain.wakeUpCall.ctaText}</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
