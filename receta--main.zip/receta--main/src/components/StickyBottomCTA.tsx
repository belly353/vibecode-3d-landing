import React, { useState, useEffect } from 'react';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface StickyBottomCTAProps {
  content: LandingContent;
}

export const StickyBottomCTA: React.FC<StickyBottomCTAProps> = ({ content }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  return (
    <aside 
      aria-label="Acceso Rápido"
      className="fixed bottom-0 left-0 right-0 z-50 bg-[#FAF9F5]/95 backdrop-blur-md border-t border-stone-200/90 shadow-2xl py-2 px-3 sm:px-6 transition-transform duration-300 transform translate-y-0 max-h-[14vh]"
    >
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        
        {/* Left price teaser */}
        <div className="hidden sm:flex items-center gap-3">
          <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
          <div className="text-left">
            <p className="text-xs font-bold text-stone-900 leading-tight">
              Más de 85+ Recetas Naturales
            </p>
            <p className="text-[11px] text-emerald-800 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-700" />
              <span>Garantía de 7 días Hotmart</span>
            </p>
          </div>
        </div>

        {/* Center price info */}
        <div className="text-left sm:text-center">
          <span className="text-[11px] text-stone-400 line-through mr-1.5 hidden xs:inline">
            {content.offer.originalPrice}
          </span>
          <span className="text-sm sm:text-base font-extrabold text-stone-900">
            {content.offer.currentPrice}
          </span>
        </div>

        {/* Right CTA button */}
        <a
          href={content.hero.checkoutUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-4 sm:px-6 py-2.5 text-xs sm:text-sm font-extrabold text-white bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 rounded-lg shadow transition-all whitespace-nowrap cursor-pointer shrink-0"
        >
          <span>Quiero Mi Guía</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </a>

      </div>
    </aside>
  );
};
