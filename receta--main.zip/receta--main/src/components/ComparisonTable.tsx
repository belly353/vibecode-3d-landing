import React from 'react';
import { XCircle, CheckCircle2, DollarSign, ArrowRight } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface ComparisonTableProps {
  content: LandingContent;
  onCtaClick: () => void;
}

export const ComparisonTable: React.FC<ComparisonTableProps> = ({ content, onCtaClick }) => {
  const { optionOld, optionNew } = content.comparison;

  return (
    <section className="py-16 lg:py-24 bg-[#F5F2EB] border-b border-stone-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="max-w-2xl mx-auto text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-stone-600">
            <DollarSign className="w-4 h-4 text-emerald-800" />
            <span>{content.comparison.kicker}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight" style={{ textWrap: 'balance' }}>
            {content.comparison.title}
          </h2>

          <p className="text-stone-600 text-sm sm:text-base">
            {content.comparison.subtitle}
          </p>
        </div>

        {/* 2 Path Comparison Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          
          {/* Card 1: The Chemical Pill Trap */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-rose-200 shadow-sm flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <span className="inline-block text-xs font-bold text-rose-800 bg-rose-50 border border-rose-200 px-3 py-1 rounded">
                {optionOld.badge}
              </span>

              <h3 className="text-xl font-extrabold text-stone-900">
                {optionOld.title}
              </h3>

              <div className="p-3 bg-rose-50/70 rounded-lg border border-rose-100 text-xs sm:text-sm font-semibold text-rose-900">
                Gasto recurrente: <span className="underline">{optionOld.cost}</span>
              </div>

              <ul className="space-y-3 text-xs sm:text-sm text-stone-700">
                {optionOld.items.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-4 border-t border-stone-200 text-xs font-medium text-rose-800 bg-rose-50/50 p-3 rounded-lg">
              {optionOld.consequence}
            </div>
          </div>

          {/* Card 2: Natural Restoration */}
          <div className="bg-emerald-950 text-white rounded-2xl p-6 sm:p-8 border-2 border-emerald-500 shadow-xl flex flex-col justify-between space-y-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-700/20 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-4 relative">
              <span className="inline-block text-xs font-bold text-amber-300 bg-emerald-900/90 border border-emerald-700 px-3 py-1 rounded">
                {optionNew.badge}
              </span>

              <h3 className="text-xl font-extrabold text-white">
                {optionNew.title}
              </h3>

              <div className="p-3 bg-emerald-900/60 rounded-lg border border-emerald-800 text-xs sm:text-sm font-semibold text-emerald-200">
                Inversión simbólica única: <span className="text-amber-300 underline font-bold">{optionNew.cost}</span>
              </div>

              <ul className="space-y-3 text-xs sm:text-sm text-emerald-100">
                {optionNew.items.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-4 border-t border-emerald-800 text-xs font-medium text-emerald-200 bg-emerald-900/40 p-3 rounded-lg">
              {optionNew.consequence}
            </div>
          </div>

        </div>

        {/* Impulse Action */}
        <div className="mt-10 text-center">
          <button
            onClick={onCtaClick}
            type="button"
            className="inline-flex items-center gap-2 px-8 py-4 text-base font-bold text-white bg-emerald-800 hover:bg-emerald-700 active:bg-emerald-900 rounded-xl shadow-lg transition-all cursor-pointer"
          >
            <span>Elijo el Camino Natural — Quiero la Guía Oficial Ahora</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
