import React, { useState } from 'react';
import { CheckSquare, Square, ArrowRight, Activity, Zap } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface SymptomCalculatorProps {
  content: LandingContent;
  onCtaClick: () => void;
}

export const SymptomCalculator: React.FC<SymptomCalculatorProps> = ({ content, onCtaClick }) => {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(['fatigue', 'bloat', 'acid']);

  const toggleSymptom = (id: string) => {
    if (selectedSymptoms.includes(id)) {
      setSelectedSymptoms(selectedSymptoms.filter((s) => s !== id));
    } else {
      setSelectedSymptoms([...selectedSymptoms, id]);
    }
  };

  const count = selectedSymptoms.length;
  const toxicityPercentage = Math.min(100, Math.round((count / content.quiz.symptoms.length) * 100));

  let statusClass = 'text-amber-700 bg-amber-50 border-amber-200';
  let statusText = content.quiz.lowScoreText;
  let severityLabel = 'Sobrecarga Leve';

  if (count >= 4) {
    statusClass = 'text-rose-700 bg-rose-50 border-rose-200';
    statusText = content.quiz.highScoreText;
    severityLabel = 'Alerta Crítica: Inflamación Severa';
  } else if (count >= 2) {
    statusClass = 'text-orange-700 bg-orange-50 border-orange-200';
    statusText = content.quiz.midScoreText;
    severityLabel = 'Alerta Moderada: Hígado Saturado';
  }

  return (
    <section id="diagnostico" className="py-16 lg:py-24 bg-[#F5F2EB] border-b border-stone-200">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-800">
            <Activity className="w-4 h-4 text-emerald-700" />
            <span>{content.quiz.kicker}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight" style={{ textWrap: 'balance' }}>
            {content.quiz.title}
          </h2>

          <p className="text-stone-600 text-sm sm:text-base">
            {content.quiz.subtitle}
          </p>
        </div>

        {/* Interactive Symptom Selector Box */}
        <div className="mt-10 bg-white rounded-2xl p-6 sm:p-8 border border-stone-300 shadow-xl space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 text-xs sm:text-sm text-stone-500">
            <span className="font-semibold text-stone-800">{content.quiz.instruction}</span>
            <span>{count} de {content.quiz.symptoms.length} seleccionados</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {content.quiz.symptoms.map((symptom) => {
              const isChecked = selectedSymptoms.includes(symptom.id);
              return (
                <button
                  key={symptom.id}
                  onClick={() => toggleSymptom(symptom.id)}
                  type="button"
                  className={`text-left p-3.5 sm:p-4 rounded-xl border transition-all flex items-start gap-3 cursor-pointer ${
                    isChecked
                      ? 'border-emerald-700 bg-emerald-50/70 text-emerald-950 shadow-sm'
                      : 'border-stone-200 hover:border-stone-300 bg-stone-50/50 text-stone-700'
                  }`}
                >
                  <div className="mt-0.5 shrink-0 text-emerald-700">
                    {isChecked ? (
                      <CheckSquare className="w-5 h-5 text-emerald-700" />
                    ) : (
                      <Square className="w-5 h-5 text-stone-400" />
                    )}
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-semibold leading-snug">{symptom.label}</p>
                    <p className="text-xs text-stone-500">{symptom.impact}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Real-time Calculation Panel */}
          <div className={`mt-6 p-5 sm:p-6 rounded-xl border ${statusClass} space-y-4`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider">{content.quiz.resultsTitle}</span>
                <h4 className="text-lg sm:text-xl font-extrabold mt-0.5">{severityLabel}</h4>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-2xl sm:text-3xl font-black tabular-nums">{toxicityPercentage}%</span>
                <span className="text-xs font-semibold leading-tight">Índice de<br/>Toxicidad</span>
              </div>
            </div>

            {/* Visual Progress Bar */}
            <div className="w-full bg-stone-200 h-2.5 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  count >= 4 ? 'bg-rose-600' : count >= 2 ? 'bg-orange-500' : 'bg-emerald-600'
                }`}
                style={{ width: `${Math.max(10, toxicityPercentage)}%` }}
              />
            </div>

            <p className="text-xs sm:text-sm leading-relaxed">{statusText}</p>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-current/15">
              <div className="flex items-center gap-2 text-xs font-semibold">
                <Zap className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Recetas de alivio prioritarias: Capítulos 1, 2 y 4 de la Guía</span>
              </div>

              <button
                onClick={onCtaClick}
                type="button"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-bold text-white bg-emerald-800 hover:bg-emerald-700 active:bg-emerald-900 rounded-lg shadow transition-all cursor-pointer whitespace-nowrap"
              >
                <span>{content.quiz.ctaText}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
