import React, { useState } from 'react';
import { Sparkles, Clock, ShieldCheck, ShoppingBag, ArrowRight, Check } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface InsideTheBookProps {
  content: LandingContent;
  onCtaClick: () => void;
}

export const InsideTheBook: React.FC<InsideTheBookProps> = ({ content, onCtaClick }) => {
  const [img1Error, setImg1Error] = useState(false);

  return (
    <section id="receitas" className="py-16 lg:py-24 bg-[#FAF9F5] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="max-w-3xl mx-auto text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-emerald-800">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>{content.solution.kicker}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight" style={{ textWrap: 'balance' }}>
            {content.solution.title}
          </h2>

          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            {content.solution.subtitle}
          </p>
        </div>

        {/* 3 Key Structural Highlights */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {content.solution.highlights.map((h, i) => (
            <div key={i} className="p-6 bg-white rounded-xl border border-stone-200 shadow-sm flex flex-col justify-start space-y-2">
              <div className="flex items-center gap-2">
                {i === 0 && <ShoppingBag className="w-5 h-5 text-emerald-700" />}
                {i === 1 && <Clock className="w-5 h-5 text-amber-600" />}
                {i === 2 && <ShieldCheck className="w-5 h-5 text-emerald-700" />}
                <h3 className="text-base font-bold text-stone-900">{h.title}</h3>
              </div>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">{h.description}</p>
            </div>
          ))}
        </div>

        {/* 5 Recipe Pillars Display */}
        <div className="mt-12 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Visual Column: Featuring official interior preview */}
            <div className="lg:col-span-5 space-y-6 sticky top-24">
              
              {/* Card showing the official book interior samples */}
              <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-md space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                  <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider">
                    Ejemplo de Ficha Real de la Guía
                  </span>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    Capítulo 1 · Receta 1
                  </span>
                </div>

                <div className="space-y-3 bg-[#FCFBF8] p-4 rounded-xl border border-stone-200/80">
                  <h4 className="text-base font-extrabold text-stone-900 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    Infusión Vientre Ligero
                  </h4>
                  <p className="text-xs text-stone-600 italic">
                    "Para apoyar la digestión ligera y aliviar la sensación de hinchazón. Combina jengibre y menta para calmar el estómago y favorecer un vientre más liviano de forma natural."
                  </p>
                  
                  <div className="pt-2 border-t border-stone-200 grid grid-cols-2 gap-2 text-xs text-stone-700">
                    <div>
                      <span className="font-bold text-stone-900 block">Ingredientes:</span>
                      <ul className="text-[11px] text-stone-600 list-disc list-inside space-y-0.5">
                        <li>3-4 rodajas de jengibre</li>
                        <li>5-6 hojas de menta fresca</li>
                        <li>1/2 limón en rodajas</li>
                        <li>250 ml agua caliente</li>
                      </ul>
                    </div>
                    <div>
                      <span className="font-bold text-stone-900 block">Cómo se prepara:</span>
                      <p className="text-[11px] text-stone-600 leading-tight">
                        Hervir 250 ml de agua, añadir jengibre y menta, reposar 5-7 min, colar y servir con gotas de limón.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-center gap-2">
                  <Check className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>Incluye advertencias, precauciones y momentos exactos de consumo.</span>
                </div>
              </div>

              {/* Natural Infusion Photography Card */}
              <div className="rounded-2xl overflow-hidden shadow-xl border border-stone-200 bg-stone-900">
                {!img1Error ? (
                  <img
                    src="/src/assets/images/herbal_infusion_detox_1792048813689.jpg"
                    alt="Infusiones y elixires naturales para el bienestar"
                    referrerPolicy="no-referrer"
                    onError={() => setImg1Error(true)}
                    className="w-full h-52 object-cover"
                  />
                ) : (
                  <div className="h-52 bg-stone-800 flex items-center justify-center text-stone-300 text-sm">
                    Preparaciones 100% Caseras y Efectivas
                  </div>
                )}
                <div className="p-3 bg-stone-900 text-stone-300 text-xs flex items-center justify-between">
                  <span>Infusiones que reemplazan decenas de fármacos</span>
                  <span className="text-emerald-400 font-bold">100% Natural</span>
                </div>
              </div>

            </div>

            {/* Content Column: The 5 Modules */}
            <div className="lg:col-span-7 space-y-4">
              {content.solution.pillars.map((pillar, idx) => (
                <div
                  key={idx}
                  className="p-5 sm:p-6 bg-white rounded-xl border border-stone-200 shadow-sm hover:border-emerald-600/40 transition-colors space-y-2.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        {pillar.number}
                      </span>
                      <h4 className="text-base sm:text-lg font-bold text-stone-900">
                        {pillar.title}
                      </h4>
                    </div>
                    <span className="text-xs font-semibold text-stone-500">
                      {pillar.recipeCount}
                    </span>
                  </div>

                  <p className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
                    {pillar.focus}
                  </p>

                  <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                    {pillar.description}
                  </p>

                  <div className="pt-2 border-t border-stone-100 flex flex-wrap gap-2 text-xs text-stone-500">
                    <span className="font-semibold text-stone-700">Recetas destacadas:</span>
                    {pillar.examples.map((ex, exIdx) => (
                      <span key={exIdx} className="bg-stone-100 px-2 py-0.5 rounded text-stone-700">
                        {ex}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>

        {/* Section Mid CTA */}
        <div className="mt-12 text-center">
          <button
            onClick={onCtaClick}
            type="button"
            className="inline-flex items-center gap-2 px-8 py-4 text-base font-bold text-white bg-emerald-800 hover:bg-emerald-700 active:bg-emerald-900 rounded-xl shadow-md transition-all cursor-pointer"
          >
            <span>Quiero Acceder a las 85+ Recetas en Mi Móvil</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

      </div>
    </section>
  );
};
