import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, Sparkles, BookOpen, Maximize2, X } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface HeroProps {
  content: LandingContent;
}

export const Hero: React.FC<HeroProps> = ({ content }) => {
  const [imageError, setImageError] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-12 lg:pb-20 border-b border-stone-200">
      {/* Background ambient light */}
      <div className="absolute top-0 right-1/4 -z-10 w-96 h-96 bg-emerald-100/50 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 -z-10 w-80 h-80 bg-amber-100/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Direct-response Persuasive Copy */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Unboxed Kicker */}
            <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-rose-700 uppercase">
              <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse" />
              <span>{content.hero.kicker}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-stone-900 leading-[1.15]" style={{ textWrap: 'balance' }}>
              {content.hero.title}{' '}
              <span className="text-emerald-800 underline decoration-amber-400 decoration-wavy decoration-2">
                {content.hero.titleHighlight}
              </span>
            </h1>

            {/* Tagline from official cover */}
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100/90 text-amber-900 rounded-lg text-xs sm:text-sm font-bold border border-amber-300">
              <Sparkles className="w-4 h-4 text-amber-700" />
              <span>🌿 {content.hero.tagline}</span>
            </div>

            {/* Emotive Subtitle */}
            <p className="text-base sm:text-lg text-stone-700 leading-relaxed max-w-2xl">
              {content.hero.subtitle}
            </p>

            {/* Bullets directly aligned with the official cover */}
            <ul className="space-y-3 pt-1">
              {content.hero.bulletPoints.map((bullet, idx) => (
                <li key={idx} className="flex items-start gap-3 text-sm sm:text-base text-stone-800">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>

            {/* Primary Action Button */}
            <div className="pt-3 space-y-3">
              <a
                href={content.hero.checkoutUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 text-base sm:text-lg font-extrabold text-white bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 rounded-xl shadow-lg shadow-emerald-900/20 hover:shadow-xl hover:-translate-y-0.5 transition-all text-center cursor-pointer"
              >
                <span>{content.hero.ctaPrimary}</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>

              {/* Trust Microcopy */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-stone-500 pt-1">
                <span className="flex items-center gap-1.5 font-medium text-stone-700">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Garantía de 7 Días Hotmart</span>
                </span>
                <span aria-hidden="true" className="text-stone-300">·</span>
                <span className="flex items-center gap-1.5 font-medium text-stone-700">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>Descarga Digital Inmediata</span>
                </span>
                <span aria-hidden="true" className="text-stone-300">·</span>
                <span className="flex items-center gap-1.5 font-medium text-stone-700">
                  <BookOpen className="w-4 h-4 text-emerald-600" />
                  <span>85+ Recetas Completas</span>
                </span>
              </div>
            </div>

          </div>

          {/* Right Column: Prominent Official Cover Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-sm sm:max-w-md lg:max-w-none rounded-2xl overflow-hidden shadow-2xl border-2 border-emerald-700/30 bg-stone-900 group">
              
              {!imageError ? (
                <div className="relative cursor-pointer" onClick={() => setIsModalOpen(true)}>
                  <img
                    src="/src/assets/images/book_cover_official.png"
                    alt="Portada Oficial: Más de 85+ Recetas Naturales para el Bienestar Diario"
                    referrerPolicy="no-referrer"
                    onError={() => setImageError(true)}
                    className="w-full h-auto object-cover group-hover:scale-[1.01] transition-transform duration-300"
                  />
                  {/* Subtle expand indicator */}
                  <div className="absolute top-3 right-3 bg-stone-950/80 text-white p-2 rounded-lg backdrop-blur-sm opacity-80 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-4 h-4" />
                  </div>
                </div>
              ) : (
                <div className="aspect-[3/4] bg-gradient-to-br from-emerald-950 via-stone-900 to-emerald-900 flex flex-col items-center justify-center p-8 text-center text-white">
                  <BookOpen className="w-16 h-16 text-emerald-400 mb-4 opacity-90" />
                  <span className="text-xl font-bold tracking-tight">Más de 85+ Recetas Naturales</span>
                  <span className="text-xs text-stone-300 mt-2">Guía Oficial de Bienestar Diario</span>
                </div>
              )}

              {/* Bottom Quick Bar */}
              <div className="p-3.5 bg-stone-950 text-white flex items-center justify-between text-xs">
                <span className="font-semibold text-emerald-300">✓ Portada y Recetas Originales</span>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(true)}
                  className="text-amber-400 hover:text-amber-300 underline font-medium cursor-pointer"
                >
                  Ver portada ampliada
                </button>
              </div>

            </div>

            {/* Floating Social Proof Strip */}
            <div className="mt-3 p-3 bg-white rounded-xl border border-stone-200 shadow-sm text-xs text-stone-700 flex items-center justify-between">
              <span className="font-semibold text-emerald-950">Más de 1.840 personas ya descargaron esta guía</span>
              <span className="text-amber-500 font-bold">★ 4.9 (Hotmart)</span>
            </div>

          </div>

        </div>
      </div>

      {/* Lightbox Modal for Full Cover Inspection */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-stone-950/90 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setIsModalOpen(false)}
        >
          <div
            className="relative max-w-2xl max-h-[90vh] bg-stone-900 rounded-2xl overflow-hidden shadow-2xl border border-stone-700 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-3 bg-stone-950 text-white flex items-center justify-between border-b border-stone-800">
              <span className="text-xs font-bold text-stone-300">Portada Oficial del Libro Digital</span>
              <button
                onClick={() => setIsModalOpen(false)}
                type="button"
                className="text-stone-400 hover:text-white p-1 rounded-md cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="overflow-auto p-2">
              <img
                src="/src/assets/images/book_cover_official.png"
                alt="Vista completa de la portada oficial"
                className="w-full h-auto rounded-lg"
              />
            </div>
            <div className="p-3 bg-stone-950 text-center border-t border-stone-800">
              <a
                href={content.hero.checkoutUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-600 rounded-lg shadow"
              >
                <span>Comprar Guía en Hotmart ($6.99)</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
