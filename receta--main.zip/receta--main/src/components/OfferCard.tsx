import React, { useState, useEffect } from 'react';
import { ShieldCheck, ArrowRight, Lock, CheckCircle2, Zap, Clock } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface OfferCardProps {
  content: LandingContent;
}

export const OfferCard: React.FC<OfferCardProps> = ({ content }) => {
  const [timeLeft, setTimeLeft] = useState<{ minutes: number; seconds: number }>({
    minutes: 14,
    seconds: 52,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { minutes: prev.minutes - 1, seconds: 59 };
        } else {
          return { minutes: 14, seconds: 59 };
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatNumber = (num: number) => String(num).padStart(2, '0');

  return (
    <section id="oferta" className="py-16 lg:py-24 bg-gradient-to-b from-[#FAF9F5] to-[#EDE8DE] border-b border-stone-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Urgency Badge Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-rose-700 bg-rose-50 border border-rose-200 px-3 py-1 rounded-full">
            <Zap className="w-3.5 h-3.5 text-rose-600 fill-rose-600" />
            <span>{content.offer.kicker}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight" style={{ textWrap: 'balance' }}>
            {content.offer.title}
          </h2>

          <p className="text-stone-600 text-sm sm:text-base max-w-xl mx-auto">
            {content.offer.subtitle}
          </p>
        </div>

        {/* The Conversion Pricing Box */}
        <div className="mt-10 bg-white rounded-3xl border-2 border-emerald-600 shadow-2xl p-6 sm:p-10 relative overflow-hidden">
          
          {/* Top Banner Ribbon */}
          <div className="bg-emerald-800 text-white text-center py-2 px-4 -mx-6 -mt-6 sm:-mx-10 sm:-mt-10 mb-6 flex items-center justify-center gap-2 text-xs sm:text-sm font-bold tracking-wide">
            <Clock className="w-4 h-4 text-amber-300" />
            <span>{content.offer.timerText}</span>
            <span className="font-mono bg-emerald-950 px-2 py-0.5 rounded text-amber-300 tabular-nums">
              {formatNumber(timeLeft.minutes)}:{formatNumber(timeLeft.seconds)}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            
            {/* Left: What's included checklist */}
            <div className="md:col-span-7 space-y-4">
              <h3 className="text-lg sm:text-xl font-bold text-stone-900">
                Lo Que Recibirás Inmediatamente en Tu Correo:
              </h3>

              <ul className="space-y-2.5 text-xs sm:text-sm text-stone-700">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Guía Completa:</strong> Más de 85+ Recetas Naturales en Alta Resolución</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Módulo 1:</strong> Protocolo de Digestión Ligera y Alivio del Vientre</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Módulo 2:</strong> Depuración Profunda del Hígado y Vías Biliares</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Módulo 3:</strong> Activación Metabólica y Quema Calórica Natural</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Módulo 4:</strong> Corazón, Circulación y Piernas Desinflamadas</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Bono de Regalo 1:</strong> Plan Detox de 7 Días para Reseteo Hepático</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Bono de Regalo 2:</strong> Guía de Sustituciones Inteligentes de Hierbas</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Bono de Regalo 3:</strong> Lista Maestra de Compras del Consumidor Consciente</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong>Acceso de Por Vida:</strong> Descarga inmediata sin pagos mensuales</span>
                </li>
              </ul>
            </div>

            {/* Right: Price Anchor & Impulse CTA */}
            <div className="md:col-span-5 bg-stone-50 rounded-2xl p-6 border border-stone-200 text-center space-y-4">
              <div>
                <p className="text-xs text-stone-400 line-through">
                  Antes {content.offer.originalPrice}
                </p>
                <p className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
                  Precio Especial de Hoy
                </p>
                <div className="text-3xl sm:text-4xl font-black text-stone-900 tracking-tight my-1">
                  {content.offer.currentPrice}
                </div>
                <p className="text-[11px] text-stone-500 leading-tight">
                  {content.offer.paymentNote}
                </p>
              </div>

              {/* Direct Hotmart Checkout Button */}
              <a
                href={content.hero.checkoutUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 text-base font-extrabold text-white bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all text-center cursor-pointer animate-pulse"
              >
                <span>{content.offer.ctaText}</span>
                <ArrowRight className="w-5 h-5" />
              </a>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-stone-500">
                <Lock className="w-3.5 h-3.5 text-emerald-700" />
                <span>Checkout 100% Blindado y Seguro Hotmart</span>
              </div>
            </div>

          </div>

          {/* Guarantee Sub-Block */}
          <div id="garantia" className="mt-8 pt-8 border-t border-stone-200 flex flex-col sm:flex-row items-center gap-6">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-10 h-10 text-emerald-700" />
            </div>
            <div className="space-y-1 text-center sm:text-left">
              <h4 className="text-base font-bold text-stone-900">
                {content.offer.guaranteeTitle}
              </h4>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                {content.offer.guaranteeText}
              </p>
            </div>
          </div>

          {/* Security Badges Strip */}
          <div className="mt-6 pt-4 border-t border-stone-100 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[11px] text-stone-500 font-medium">
            {content.offer.securityBadges.map((badge, idx) => (
              <span key={idx} className="bg-stone-50 py-1.5 px-2 rounded border border-stone-200/60">
                ✓ {badge}
              </span>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
