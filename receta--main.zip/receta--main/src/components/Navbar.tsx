import React from 'react';
import { ArrowRight } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface NavbarProps {
  content: LandingContent;
  onCtaClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ content, onCtaClick }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F5]/95 backdrop-blur-md border-b border-stone-200/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand title, one line text element */}
        <a
          href="#"
          className="text-lg sm:text-xl font-extrabold tracking-tight text-emerald-950 hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />
          <span>{content.nav.brand}</span>
        </a>

        {/* Zone 2: 4-5 single-line clean navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-stone-600">
          {content.nav.links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="hover:text-emerald-900 transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-4 decoration-emerald-500/50"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onCtaClick}
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-bold text-white bg-emerald-800 hover:bg-emerald-700 active:bg-emerald-900 rounded-lg shadow-sm hover:shadow transition-all whitespace-nowrap cursor-pointer"
          >
            <span>{content.nav.cta}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </header>
  );
};
