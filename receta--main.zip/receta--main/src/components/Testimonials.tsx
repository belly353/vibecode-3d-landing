import React from 'react';
import { Star, Quote, CheckCircle } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface TestimonialsProps {
  content: LandingContent;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ content }) => {
  return (
    <section id="testimonios" className="py-16 lg:py-24 bg-[#F5F2EB] border-b border-stone-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-800">
            <Quote className="w-4 h-4 text-emerald-700" />
            <span>{content.testimonials.kicker}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight" style={{ textWrap: 'balance' }}>
            {content.testimonials.title}
          </h2>

          <p className="text-stone-600 text-sm sm:text-base">
            {content.testimonials.subtitle}
          </p>
        </div>

        {/* 3 Real Testimonial Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {content.testimonials.items.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 sm:p-7 border border-stone-200 shadow-sm flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Rating stars */}
                <div className="flex items-center gap-1 text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Concrete result headline */}
                <h3 className="text-sm sm:text-base font-bold text-stone-900">
                  "{item.result}"
                </h3>

                {/* Quote */}
                <p className="text-xs sm:text-sm text-stone-600 leading-relaxed italic">
                  "{item.quote}"
                </p>
              </div>

              {/* Author footer */}
              <div className="pt-4 border-t border-stone-100 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs sm:text-sm font-bold text-stone-900">{item.name}</span>
                  <span className="text-xs text-stone-500">{item.age}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-stone-500">
                  <span>{item.location}</span>
                  <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                    <CheckCircle className="w-3 h-3" />
                    {item.timeframe}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Social Proof Stats Banner */}
        <div className="mt-12 max-w-3xl mx-auto bg-white rounded-xl border border-stone-200 p-6 flex flex-wrap items-center justify-around gap-4 text-center">
          <div>
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-900 tabular-nums">+85</p>
            <p className="text-xs text-stone-500 mt-0.5">Recetas Catalogadas</p>
          </div>
          <div className="w-px h-10 bg-stone-200 hidden sm:block" />
          <div>
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-900 tabular-nums">4.9/5</p>
            <p className="text-xs text-stone-500 mt-0.5">Valoración en Hotmart</p>
          </div>
          <div className="w-px h-10 bg-stone-200 hidden sm:block" />
          <div>
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-900 tabular-nums">100%</p>
            <p className="text-xs text-stone-500 mt-0.5">Ingredientes Naturales</p>
          </div>
        </div>

      </div>
    </section>
  );
};
