import React from 'react';
import type { LandingContent } from '../data/content';

interface FooterProps {
  content: LandingContent;
}

export const Footer: React.FC<FooterProps> = ({ content }) => {
  return (
    <footer className="bg-stone-900 text-stone-400 py-12 text-xs border-t border-stone-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Medical / Educational Disclaimer */}
        <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 leading-relaxed text-stone-400">
          <p className="font-semibold text-stone-300 mb-1">Aviso de Responsabilidad Médica y Educativa:</p>
          <p>{content.footer.disclaimer}</p>
        </div>

        {/* Footer Bottom Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-stone-800 text-stone-400">
          <p>{content.footer.rights}</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-stone-300">Términos de Uso</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-stone-300">Políticas de Privacidad</span>
            <span aria-hidden="true">·</span>
            <a
              href="https://pay.hotmart.com/F108039909R"
              target="_blank"
              rel="noopener noreferrer"
              className="text-emerald-400 hover:text-emerald-300 font-semibold"
            >
              Checkout Oficial Hotmart
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
};
