import React from 'react';
import { Gift, Check, Clock } from 'lucide-react';
import type { LandingContent } from '../data/content';

interface BonusesProps {
  content: LandingContent;
}

export const Bonuses: React.FC<BonusesProps> = ({ content }) => {
  return (
    <section className="py-16 lg:py-24 bg-[#FAF9F5] border-b border-stone-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-700">
            <Gift className="w-4 h-4 text-amber-600" />
            <span>{content.bonuses.kicker}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-stone-900 tracking-tight" style={{ textWrap: 'balance' }}>
            {content.bonuses.title}
          </h2>

          <p className="text-stone-600 text-sm sm:text-base">
            {content.bonuses.subtitle}
          </p>
        </div>

        {/* 3 Bonus Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {content.bonuses.items.map((bonus, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 border border-stone-200 shadow-sm flex flex-col justify-between hover:border-amber-400 transition-colors space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-900 bg-amber-100/80 px-2.5 py-1 rounded-md border border-amber-200">
                    {bonus.badge}
                  </span>
                  <span className="text-xs font-extrabold text-emerald-700 uppercase">
                    100% Gratis
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-stone-900 leading-snug">
                  {bonus.title}
                </h3>

                <p className="text-xs text-stone-400 line-through">
                  {bonus.originalPrice}
                </p>

                <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                  {bonus.description}
                </p>
              </div>

              <div className="pt-3 border-t border-stone-100 flex items-center gap-2 text-xs font-semibold text-emerald-800">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Incluido en tu descarga de hoy</span>
              </div>
            </div>
          ))}
        </div>

        {/* Bonus Guarantee Banner */}
        <div className="mt-8 p-4 bg-amber-50 rounded-xl border border-amber-200/80 max-w-3xl mx-auto flex items-center justify-center gap-3 text-xs sm:text-sm text-amber-900 text-center">
          <Clock className="w-4 h-4 text-amber-700 shrink-0" />
          <span>Atención: Los 3 bonos se entregan automáticamente a tu correo electrónico junto con la guía digital oficial.</span>
        </div>

      </div>
    </section>
  );
};
