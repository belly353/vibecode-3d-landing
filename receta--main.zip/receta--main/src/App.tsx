import { spanishContent } from './data/content';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SilentAlert } from './components/SilentAlert';
import { SymptomCalculator } from './components/SymptomCalculator';
import { InsideTheBook } from './components/InsideTheBook';
import { ComparisonTable } from './components/ComparisonTable';
import { Bonuses } from './components/Bonuses';
import { Testimonials } from './components/Testimonials';
import { OfferCard } from './components/OfferCard';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';
import { StickyBottomCTA } from './components/StickyBottomCTA';
import { ShieldAlert } from 'lucide-react';

export default function App() {
  const content = spanishContent;

  const scrollToOffer = () => {
    const el = document.getElementById('oferta');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.open(content.hero.checkoutUrl, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-[#1C1F1D] flex flex-col selection:bg-emerald-200 selection:text-emerald-950">
      
      {/* Top Urgency Strip */}
      <aside aria-label="Alerta de Promoción" className="bg-amber-400 text-stone-950 py-1.5 px-4 text-center text-xs font-bold tracking-tight border-b border-amber-500/50 flex items-center justify-center gap-2">
        <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
        <span>{content.urgencyBanner}</span>
      </aside>

      {/* Top Navigation Bar adhering to 3-Zone Contract */}
      <Navbar
        content={content}
        onCtaClick={scrollToOffer}
      />

      <main className="flex-1">
        {/* 1. Hero Section with visceral hook and official book cover */}
        <Hero content={content} />

        {/* 2. The Real Pain & Healthy Fear of Delay ("La Alerta Silenciosa") */}
        <SilentAlert content={content} onCtaClick={scrollToOffer} />

        {/* 3. Interactive Biological Overload Test */}
        <SymptomCalculator content={content} onCtaClick={scrollToOffer} />

        {/* 4. Inside the 85+ Recipes Guide & Real Recipe Previews */}
        <InsideTheBook content={content} onCtaClick={scrollToOffer} />

        {/* 5. The Comparison: Pharmacy Trap vs Natural Wisdom */}
        <ComparisonTable content={content} onCtaClick={scrollToOffer} />

        {/* 6. 3 Fast-Action Free Bonus Guides */}
        <Bonuses content={content} />

        {/* 7. Social Proof & Attributable Testimonials */}
        <Testimonials content={content} />

        {/* 8. Conversion Epicenter: Offer Card & 7-Day Guarantee */}
        <OfferCard content={content} />

        {/* 9. Frequently Asked Questions Accordion */}
        <FAQ content={content} />
      </main>

      {/* 10. Footer with Legal and Medical Disclaimer */}
      <Footer content={content} />

      {/* 11. Sticky Mobile / Bottom Impulse Bar (<15% viewport height) */}
      <StickyBottomCTA content={content} />

    </div>
  );
}
